﻿namespace com.blogging.web.Models.ViewModel
{
    public class AddTagRequest
    {
        public string Name { get; set; }
        public string DisplayName { get; set; }
    }
}
